Accompanying document for the wimlib library v1.13.3

- Description
The library, 'libwim-15.dll' (and '.\x64\libwim-15.dll' for 64-bit), namely wimlib, is distributed under the terms of the GNU Lesser General Public License version 3 (http://www.gnu.org/licenses/lgpl.html).
See ..\COPYING.LGPLv3.txt for further details on the library license.
wimlib Copyright (C) 2012-2021 Eric Biggers

- Source code
The source code is available at https://wimlib.net

- Attaching
The source code have not been changed in any way, and library is being called via the standard LoadLibrary() Windows API.

- Upgrading
You can upgrade the library by simply replacing the file(s) with a different version. Just be careful to put a 64-bit version in the 'x64' subdirectory.